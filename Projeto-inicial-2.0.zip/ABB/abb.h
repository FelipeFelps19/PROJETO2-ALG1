#ifndef ABB_H
#define ABB_H

#include <stdio.h>
#include <stdbool.h>
#include <sys/types.h>  
#include "../Item_indice/item_indice.h"

typedef struct abb ABB;

// cria uma abb vazia.
ABB *abb_criar(void);

// libera todos os nos, seus itens e a propria arvore.
void abb_apagar(ABB **t);

// insere o item, se a chave ja existe, os offsets vao para o item do no e o item e liberado.
bool abb_inserir(ABB *t, ITEM_INDICE *item);

// procura a chave do item e devolve o item da arvore com todos os offsets, ou null se nao existir.
// soma em comparacoes as comparacoes de chave feitas.
const ITEM_INDICE *abb_buscar(const ABB *t, const ITEM_INDICE *item, long *comparacoes);

// altura da arvore, vazia = -1.
int abb_altura(const ABB *t);

// metricas da construcao
int  abb_n_chaves(const ABB *t);      // distinct_keys
long abb_comparacoes(const ABB *t);   // insert_comparisons
long abb_rotacoes(const ABB *t);      // rotations, sempre 0 na abb

// grava a arvore no arquivo, preservando a topologia, devolve false em erro.
bool abb_salvar(const ABB *t, FILE *fp);

// le uma arvore gravada por abb_salvar, devolve null em erro ou se faltar memoria.
ABB *abb_carregar(FILE *fp);

#endif