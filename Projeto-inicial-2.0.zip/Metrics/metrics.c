#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <time.h>
#include "metrics.h"

double now_ms(void){
    struct timespec ts;
    clock_gettime(CLOCK_MONOTONIC, &ts);
    return ts.tv_sec * 1000.0 + ts.tv_nsec / 1e6;
}

void print_buildmetrics(const char *tree, const char *key, const buildmetrics *m) {
    printf("STATUS=OK\n");
    printf("TREE=%s\n", tree);
    printf("KEY=%s\n", key);
    printf("INPUT_RECORDS=%lld\n", m->input_records);
    printf("INDEXED_RECORDS=%lld\n", m->indexed_records);
    printf("DISTINCT_KEYS=%lld\n", m->distinct_keys);
    printf("TREE_HEIGHT=%d\n", m->tree_height);
    printf("INSERT_COMPARISONS=%lld\n", m->insert_comparisons);
    printf("ROTATIONS=%lld\n", m->rotations);
    printf("RECOLORS=%lld\n", m->recolors);
    printf("BUILD_MS=%.3f\n", m->build_ms);
    printf("SAVE_INDEX_MS=%.3f\n", m->save_index_ms);
}

void print_searchmetrics(const searchmetrics *m) {
    printf("STATUS=OK\n");
    printf("INDEX_COUNT=%d\n", m->index_count);
    printf("QUERY_KEYS=%lld\n", m->query_keys);
    printf("SEARCH_COMPARISONS=%lld\n", m->search_comparisons);
    printf("MATCHED_OFFSETS=%lld\n", m->matched_offsets);
    printf("OUTPUT_RECORDS=%lld\n", m->output_records);
    printf("LOAD_INDEX_MS=%.3f\n", m->load_index_ms);
    printf("SEARCH_MS=%.3f\n", m->search_ms);
    printf("FETCH_MS=%.3f\n", m->fetch_ms);
    printf("WRITE_MS=%.3f\n", m->write_ms);
    printf("TOTAL_MS=%.3f\n", m->total_ms);
}