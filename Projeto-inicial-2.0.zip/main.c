#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include <sys/types.h>

#include "Metrics/metrics.h"
#include "Item_indice/item_indice.h"
#include "Indice/indice.h"
#include "ABB/abb.h"
#include "AVL/avl.h"
#include "Rubro_negra/rubro-negra.h"
#include "Reader_MEC/reader_mec.h"
#include "Reader_Nasa/reader_nasa.h"


int main(int argc, char *argv[]){
    char *modo = NULL;
    char *reader = NULL;
    char *input = NULL;
    char *arvore = NULL;
    char *chave = NULL;
    char *query = NULL;
    char *output = NULL;
    int limit = 0;

    char *indices[16];
    int n_indices = 0;

    for (int i = 1; i < argc; i++){
        if      ( strcmp(argv[i], "--mode")   == 0 ) modo   = argv[++i];
        else if ( strcmp(argv[i], "--reader") == 0 ) reader = argv[++i];
        else if ( strcmp(argv[i], "--input")  == 0 ) input  = argv[++i];
        else if ( strcmp(argv[i], "--tree")   == 0 ) arvore = argv[++i];
        else if ( strcmp(argv[i], "--key")    == 0 ) chave  = argv[++i];
        else if ( strcmp(argv[i], "--query")  == 0 ) query  = argv[++i];
        else if ( strcmp(argv[i], "--output") == 0 ) output = argv[++i];
        else if ( strcmp(argv[i], "--limit")  == 0 ) limit  = atol(argv[++i]);
        else if ( strcmp(argv[i], "--index")  == 0 && n_indices < 16 ) indices[n_indices++] = argv[++i];
    }
    
    if ( modo == NULL || reader == NULL || input == NULL ){
        printf("STATUS=ERRO\n");
        return 1;
    }


    int (*reader_indice_coluna)(FILE *fp, const char *nome_coluna);
    bool (*reader_ler_chave)(FILE *fp, int idx_coluna, char *chave, int tam_chave, off_t *offset);

    if ( strcmp (reader,"nasa") == 0){
        reader_indice_coluna = reader_nasa_indice_coluna;
        reader_ler_chave = reader_nasa_ler_chave;
    }else if (strcmp(reader,"MEC") == 0){
        reader_indice_coluna = reader_mec_indice_coluna;
        reader_ler_chave = reader_mec_ler_chave;
    }else{
        printf("STATUS=ERRO\n");
        return 1;
    }

    FILE *fp = fopen(input,"r");
    if ( fp == NULL ) return 1;



    if ( strcmp(modo, "index") == 0){
        buildmetrics m = {0};
        INDICE *ind = NULL;
        int status = 1;

        if ( arvore == NULL || chave == NULL || n_indices == 0){
            printf("STATUS=ERRO\n");
            return 1;
        }
        int indice_coluna = reader_indice_coluna(fp,chave);

        if (indice_coluna < 0){
            printf("STATUS=ERRO\n");
            return 1;
        }

        ind = indice_criar(arvore);
        if ( ind == NULL ){
            printf("STATUS=ERRO\n");
            return 1;
        }

        char chave_lida[256];
        off_t offset;
        long lidos = 0, indexados = 0;

        
        // Construção:

        double t0 = now_ms();
        while( (limit == 0 || lidos < limit) && reader_ler_chave(fp, indice_coluna, chave_lida,sizeof(chave_lida),&offset)){
            lidos++;
            ITEM_INDICE *item = item_indice_criar(chave_lida, offset);
            if ( item != NULL && indice_inserir(ind, item) ){
                indexados++;
            }else{
                item_indice_apagar(&item);
            }
        }
        
        m.build_ms = now_ms() - t0;
        m.input_records = lidos;
        m.indexed_records = indexados;
        m.distinct_keys = indice_n_chaves(ind);
        m.tree_height = indice_altura(ind);
        m.insert_comparisons = indice_comparacoes(ind);
        m.rotations = indice_rotacoes(ind);
        m.recolors = indice_trocas_cor(ind);

        t0 = now_ms();
        int ok = indice_salvar(ind, fp); // ta errado !
        m.save_index_ms = now_ms() - t0;        

        if(ok) {
            print_buildmetrics(arvore, chave, &m);
            status = 0;
        } else printf("STATUS=ERRO\n");

        indice_apagar(&ind);
        return status;

    }else if ( strcmp(modo, "search") == 0 ){
        
        



    }else{
        printf("STATUS: ERRO\n");
        return 1;
    }


    fclose(fp);
    return 0;
}
