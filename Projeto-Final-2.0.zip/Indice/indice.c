#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "indice.h"
#include "../ABB/abb.h"
#include "../AVL/avl.h"
#include "../Rubro_negra/rubro-negra.h"

#define ARV_ABB 0
#define ARV_AVL 1
#define ARV_ARB 2

struct indice{
    int tipo;
    ABB *abb;
    AVL *avl;
    ARB *arb;
};

INDICE *indice_criar(const char *nome_arvore){
    if ( nome_arvore == NULL ) return NULL;

    INDICE *ind = (INDICE*) malloc(sizeof(INDICE));
    if ( ind == NULL ) return NULL;

    ind->abb = NULL;
    ind->avl = NULL;
    ind->arb = NULL;

    if ( strcmp(nome_arvore,"abb") == 0 ){
        ind->tipo = ARV_ABB;
        ind->abb = abb_criar();
        if ( ind->abb == NULL ){
            free(ind);
            return NULL;
        }
    }else if ( strcmp(nome_arvore,"avl") == 0 ){
        ind->tipo = ARV_AVL;
        ind->avl = avl_criar();
        if ( ind->avl == NULL ){
            free(ind);
            return NULL;
        }
    }else if ( strcmp(nome_arvore,"rubro_negra") == 0){
        ind->tipo = ARV_ARB;
        ind->arb = arb_criar();
        if ( ind->arb == NULL ){
            free(ind);
            return NULL;
        }
    }else{
        free(ind);
        return NULL;
    }
    return ind;
}

void indice_apagar(INDICE **ind){
    if ( ind == NULL || *ind == NULL ) return;
    switch ( (*ind)->tipo ){
        case ARV_ABB: abb_apagar(&(*ind)->abb); break;
        case ARV_AVL: avl_apagar(&(*ind)->avl); break;
        case ARV_ARB: arb_apagar(&(*ind)->arb); break;
    }
    free(*ind);
    *ind = NULL;
}

bool indice_inserir(INDICE *ind, ITEM_INDICE *item){
    if ( ind == NULL ) return false;
    switch ( ind->tipo ){
        case ARV_ABB: return abb_inserir(ind->abb, item);
        case ARV_AVL: return avl_inserir(ind->avl, item);
        case ARV_ARB: return arb_inserir(ind->arb, item);
    }
    return false;
}

const ITEM_INDICE *indice_buscar(const INDICE *ind, const ITEM_INDICE *item, long *comparacoes){
    if ( ind == NULL ) return NULL;
    switch ( ind->tipo ){
        case ARV_ABB: return abb_buscar(ind->abb, item, comparacoes);
        case ARV_AVL: return avl_buscar(ind->avl, item, comparacoes);
        case ARV_ARB: return arb_buscar(ind->arb, item, comparacoes);
    }
    return NULL;
}

int indice_altura(const INDICE *ind){
    if ( ind == NULL ) return -1;
    switch ( ind->tipo ){
        case ARV_ABB: return abb_altura(ind->abb);
        case ARV_AVL: return avl_altura(ind->avl);
        case ARV_ARB: return arb_altura(ind->arb);
    }
    return -1;
}

int indice_n_chaves(const INDICE *ind){
    if ( ind == NULL ) return -1;
    switch ( ind->tipo ){
        case ARV_ABB: return abb_n_chaves(ind->abb);
        case ARV_AVL: return avl_n_chaves(ind->avl);
        case ARV_ARB: return arb_n_chaves(ind->arb);
    }
    return -1;
}

long long indice_comparacoes(const INDICE *ind){
    if ( ind == NULL ) return -1;
    switch ( ind->tipo ){
        case ARV_ABB: return abb_comparacoes(ind->abb);
        case ARV_AVL: return avl_comparacoes(ind->avl);
        case ARV_ARB: return arb_comparacoes(ind->arb);
    }
    return -1;
}

long long indice_rotacoes(const INDICE *ind){
    if ( ind == NULL ) return -1;
    switch ( ind->tipo ){
        case ARV_ABB: return abb_rotacoes(ind->abb);
        case ARV_AVL: return avl_rotacoes(ind->avl);
        case ARV_ARB: return arb_rotacoes(ind->arb);
    }
    return -1;
}

long long indice_trocas_cor(const INDICE *ind){
    if ( ind == NULL ) return -1;
    switch ( ind->tipo ){
        case ARV_ABB: return 0;
        case ARV_AVL: return avl_trocas_cor(ind->avl);
        case ARV_ARB: return arb_trocas_cor(ind->arb);
    }
    return -1;
}

bool indice_salvar(const INDICE *ind, FILE *fp){
    if ( ind == NULL || fp == NULL ) return 0;

    if ( fwrite(&ind->tipo, sizeof(int), 1, fp) != 1 ) return false;

    switch ( ind->tipo ){
        case ARV_ABB: return abb_salvar(ind->abb, fp);
        case ARV_AVL: return avl_salvar(ind->avl, fp);
        case ARV_ARB: return arb_salvar(ind->arb, fp);
    }
    return false;
}

INDICE *indice_carregar(FILE *fp){

    if ( fp == NULL ) return NULL;

    int tipo;
    if ( fread(&tipo, sizeof(int), 1, fp) != 1) return NULL;
    INDICE *ind = (INDICE*) malloc(sizeof(INDICE));
    if ( ind == NULL ) return NULL;
    ind->tipo = tipo;
    ind->abb = NULL;
    ind->avl = NULL;
    ind->arb = NULL;

    switch ( tipo ){
        case ARV_ABB: ind->abb = abb_carregar(fp); if ( ind->abb != NULL ) return ind; break;
        case ARV_AVL: ind->avl = avl_carregar(fp); if ( ind->avl != NULL ) return ind; break;
        case ARV_ARB: ind->arb = arb_carregar(fp); if ( ind->arb != NULL ) return ind; break;
    }

    free(ind);
    return NULL;
}