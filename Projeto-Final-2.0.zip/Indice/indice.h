#ifndef INDICE_H
#define INDICE_H

#include <stdio.h>
#include <stdbool.h>
#include "../Item_indice/item_indice.h"

typedef struct indice INDICE;

// cria um indice vazio da arvore escolhida, nome_arvore e "abb", "avl" ou "rubro_negra" e devolve null se o nome for invalido ou faltar memoria.
INDICE *indice_criar(const char *nome_arvore);

// libera a arvore escolhida e o proprio indice.
void    indice_apagar(INDICE **ind);

// insere o item na arvore escolhida, se a chave ja existe, os offsets vao para o item do no e o item e liberado.
// devolve false se faltar memoria, e o item continua sendo seu.
bool    indice_inserir(INDICE *ind, ITEM_INDICE *item);

// procura a chave do item na arvore escolhida e devolve o item da arvore com todos os offsets, ou null se nao existir.
// soma em comparacoes as comparacoes de chave feitas.
const ITEM_INDICE *indice_buscar(const INDICE *ind, const ITEM_INDICE *item, long *comparacoes);

// altura da arvore, vazia = -1, so a raiz = 0.
int       indice_altura(const INDICE *ind);


// metricas da construcao
int       indice_n_chaves(const INDICE *ind);    // distinct_keys
long long indice_comparacoes(const INDICE *ind); // insert_comparisons
long long indice_rotacoes(const INDICE *ind);    // rotations, rotacao dupla conta 2
long long indice_trocas_cor(const INDICE *ind);  // recolors, sempre 0 na abb e na avl

// grava a arvore no arquivo, preservando a topologia, devolve false em erro.
bool indice_salvar(const INDICE *ind, FILE *fp);

// le uma arvore gravada por indice_salvar, devolve null em erro ou se faltar memoria.
INDICE *indice_carregar(FILE *fp);

#endif