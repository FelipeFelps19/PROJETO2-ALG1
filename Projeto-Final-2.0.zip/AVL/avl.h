#ifndef AVL_H
#define AVL_H

#include <stdio.h>
#include <stdbool.h>
#include <sys/types.h> // tipo de dado grande o suficiente
#include "../Item_indice/item_indice.h"

typedef struct avl AVL;

// cria uma avl vazia, devolve null se faltar memoria.
AVL *avl_criar(void);

// libera todos os nos, seus itens e a propria arvore.
void avl_apagar(AVL **t);

// insere o item, rebalanceando por rotacoes, se a chave ja existe, os offsets vao para o item do no e o item e liberado.
// devolve false se faltar memoria, e o item continua sendo seu.
bool avl_inserir(AVL *t, ITEM_INDICE *item);

// procura a chave do item e devolve o item da arvore com todos os offsets, ou null se nao existir.
// soma em comparacoes as comparacoes de chave feitas.
const ITEM_INDICE *avl_buscar(const AVL *t, const ITEM_INDICE *item, long *comparacoes);

// altura da arvore, vazia = -1.
int avl_altura(const AVL *t);

// metricas da construcao
int  avl_n_chaves(const AVL *t);      // distinct_keys
long long avl_comparacoes(const AVL *t);   // insert_comparisons
long long avl_rotacoes(const AVL *t);      // rotations, rotacao dupla conta 2
long long avl_trocas_cor(const AVL *t);    // recolors, sempre 0 na avl

// grava a arvore no arquivo, preservando a topologia e as alturas, devolve false em erro.
bool avl_salvar(const AVL *t, FILE *fp);

// le uma arvore gravada por avl_salvar, devolve null em erro ou se faltar memoria.
AVL *avl_carregar(FILE *fp);

#endif