#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "avl.h"

typedef struct no {
    ITEM_INDICE *item;
    int altura;
    struct no *dir;
    struct no *esq;
} NO;

struct avl {
    NO *raiz;
    int n_chaves;
    long long rotacoes;
    long long comparacoes;
};

AVL *avl_criar(void){
    AVL* t = (AVL*) malloc(sizeof(AVL));
    if ( t == NULL ) return NULL;
    t->raiz = NULL;
    t->comparacoes = 0;
    t->n_chaves = 0;
    t->rotacoes = 0;
    return t;
}

static void apagar_recursivo(NO **atual){
    if ( atual == NULL || *atual == NULL ) return;

    apagar_recursivo(&(*atual)->esq);
    apagar_recursivo(&(*atual)->dir);

    item_indice_apagar(&(*atual)->item);
    free(*atual);
    *atual = NULL;
}

void avl_apagar(AVL **t){
    if (t == NULL || *t == NULL) return;
    apagar_recursivo(&(*t)->raiz);
    free(*t);
    *t = NULL;
}

static int altura(NO* A){
    if ( A == NULL ) return -1;
    return A->altura;
}

static int atualiza_altura(NO* A){
    if ( A == NULL ) return -1;

    int altura_esq = altura(A->esq);
    int altura_dir = altura(A->dir);

    return ( altura_esq > altura_dir ? altura_esq : altura_dir) + 1 ;
}

static NO* rotacao_direita(NO* A, AVL *avl){
    NO *B = A->esq;
    NO *T = B->dir;

    B->dir = A;
    A->esq = T;
    
    A->altura = atualiza_altura(A);
    B->altura = atualiza_altura(B);

    avl->rotacoes++;

    return B;
}

static NO *rotacao_esquerda(NO *A, AVL *avl){
    NO *B = A->dir;
    NO *T = B->esq;

    B->esq = A;
    A->dir = T;

    A->altura = atualiza_altura(A);
    B->altura = atualiza_altura(B);

    avl->rotacoes++;

    return B;
}

NO *rotacao_esquerda_direita(NO *A, AVL *avl){
    A->esq = rotacao_esquerda(A->esq,avl);
    return rotacao_direita(A,avl);
}

NO *rotacao_direita_esquerda(NO *A, AVL *avl){
    A->dir = rotacao_direita(A->dir,avl);
    return rotacao_esquerda(A,avl);
}

static NO *inserir_recursivo(NO *atual, ITEM_INDICE *item,bool *sucesso, AVL *avl){
    if ( atual == NULL ){
        NO* novo = (NO*) malloc(sizeof(NO));
        if (novo == NULL) return NULL;
        novo->item = item;
        novo->dir = NULL;
        novo->esq = NULL;
        novo->altura = 0;
        avl->n_chaves++;
        *sucesso = true;
        return novo;
    }

    // retorna < 0 se a chave for menor, == 0 se a chave for igual e > 0 se for maior
    int cmp = strcmp(item_indice_get_chave(item), item_indice_get_chave(atual->item));
    avl->comparacoes++;

    if ( cmp < 0 ) {
        atual->esq = inserir_recursivo(atual->esq,item,sucesso,avl);
    }else if( cmp > 0 ) {
        atual->dir = inserir_recursivo(atual->dir,item,sucesso,avl);
    }else{
        // chave repetida: passa os offsets do item novo para o item do nó
        int n = item_indice_get_n_offsets(item);
        for (int i = 0; i < n; i++){
            item_indice_adicionar_offset(atual->item,item_indice_get_offset(item,i)); // adiciona os offsets do item ao item da arvore
        }
        item_indice_apagar(&item);
        *sucesso = true;
    }

    atual->altura = atualiza_altura(atual);
    int fb = altura(atual->esq) - altura(atual->dir);

    if ( fb > 1 ){
        NO *esq = atual->esq;
        int fb_esq = altura(esq->esq) - altura(esq->dir);
        if ( fb_esq < 0 ){
            atual = rotacao_esquerda_direita(atual,avl);
        }else{
            atual = rotacao_direita(atual,avl);
        }
    }else if ( fb < -1 ){
        NO *dir = atual->dir;
        int fb_dir = altura(dir->esq) - altura(dir->dir);
        if ( fb_dir > 0 ){
            atual = rotacao_direita_esquerda(atual,avl);
        }else{
            atual = rotacao_esquerda(atual,avl);
        }
    }

    return atual;
}

bool avl_inserir(AVL *t, ITEM_INDICE *item){
    if ( t == NULL || item == NULL) return false;
    bool sucesso = false;
    t->raiz = inserir_recursivo(t->raiz,item,&sucesso,t);
    return sucesso;
}


static ITEM_INDICE *buscar_recursivo( NO* atual, const char *chave, long *comparacoes ){
    if ( atual == NULL ) return NULL;

    // retorna < 0 se a chave for menor, == 0 se a chave for igual e > 0 se for maior
    int cmp = strcmp(chave, item_indice_get_chave(atual->item));
    if ( comparacoes != NULL ) (*comparacoes)++;

    if ( cmp == 0 ) {
        return atual->item;
    }else if ( cmp < 0 ){
        return buscar_recursivo(atual->esq,chave,comparacoes);
    }else{
        return buscar_recursivo(atual->dir,chave,comparacoes);
    }
}

const ITEM_INDICE *avl_buscar(const AVL *t, const ITEM_INDICE *item, long *comparacoes){
    if ( t == NULL || item == NULL ) return NULL;
    return buscar_recursivo(t->raiz,item_indice_get_chave(item),comparacoes);
}


int avl_altura(const AVL *t){
    if ( t == NULL ) return -1;
    return altura(t->raiz);
}

int avl_n_chaves(const AVL *t){
    if ( t == NULL ) return -1;
    return t->n_chaves;
}

long long avl_comparacoes(const AVL *t){
    if ( t == NULL ) return -1;
    return t->comparacoes;
}

long long avl_rotacoes(const AVL *t){
    if ( t == NULL ) return -1;
    return t->rotacoes;
}

long long avl_trocas_cor(const AVL *t){
    return 0;
}

static bool salvar_no(const NO *atual, FILE *fp){
    if ( atual == NULL ) return true;

    const char *chave = item_indice_get_chave(atual->item);
    int tam = (int) strlen(chave);
    int n = item_indice_get_n_offsets(atual->item);
    int alt = atual->altura;
    unsigned char tem_esq = ( atual->esq != NULL );
    unsigned char tem_dir = ( atual->dir != NULL );

    if ( fwrite(&tam, sizeof(int), 1, fp) != 1 ) return false;
    if ( fwrite(chave, 1, tam, fp) != (size_t) tam ) return false;
    if ( fwrite(&n, sizeof(int), 1, fp) != 1 ) return false;

    for (int i = 0; i < n; i++){
        long long off = (long long) item_indice_get_offset(atual->item, i);
        if ( fwrite(&off, sizeof(long long), 1, fp) != 1 ) return false;
    }

    if ( fwrite(&alt, sizeof(int), 1, fp) != 1 ) return false;
    if ( fwrite(&tem_esq, 1, 1, fp) != 1 ) return false;
    if ( fwrite(&tem_dir, 1, 1, fp) != 1 ) return false;

    return salvar_no(atual->esq, fp) && salvar_no(atual->dir, fp);
}

bool avl_salvar(const AVL *t, FILE *fp){
    if ( t == NULL || fp == NULL ) return false;
    if ( fwrite(&t->n_chaves, sizeof(int), 1, fp) != 1 ) return false;
    return salvar_no(t->raiz, fp);
}

static NO *carregar_no(FILE *fp){
    int tam, n, alt;
    unsigned char tem_esq, tem_dir;

    if ( fread(&tam, sizeof(int), 1, fp) != 1 || tam < 0 ) return NULL;

    char *chave = (char*) malloc(tam + 1);
    if ( chave == NULL ) return NULL;

    if ( fread(chave, 1, tam, fp) != (size_t) tam ){
        free(chave);
        return NULL;
    }
    chave[tam] = '\0';

    if ( fread(&n, sizeof(int), 1, fp) != 1 || n < 1 ){
        free(chave);
        return NULL;
    }

    ITEM_INDICE *item = NULL;
    for (int i = 0; i < n; i++){
        long long off;
        bool ok = ( fread(&off, sizeof(long long), 1, fp) == 1 );

        if ( ok && i == 0 ){
            item = item_indice_criar(chave, (off_t) off);
            ok = ( item != NULL );
        }else if ( ok ){
            ok = item_indice_adicionar_offset(item, (off_t) off);
        }

        if ( !ok ){
            free(chave);
            if ( item != NULL ) item_indice_apagar(&item);
            return NULL;
        }
    }
    free(chave);

    if ( fread(&alt, sizeof(int), 1, fp) != 1 ||
         fread(&tem_esq, 1, 1, fp) != 1 ||
         fread(&tem_dir, 1, 1, fp) != 1 ){
        item_indice_apagar(&item);
        return NULL;
    }

    NO *no = (NO*) malloc(sizeof(NO));
    if ( no == NULL ){
        item_indice_apagar(&item);
        return NULL;
    }
    no->item = item;
    no->altura = alt;
    no->esq = NULL;
    no->dir = NULL;

    if ( tem_esq ){
        no->esq = carregar_no(fp);
        if ( no->esq == NULL ){
            apagar_recursivo(&no);
            return NULL;
        }
    }
    if ( tem_dir ){
        no->dir = carregar_no(fp);
        if ( no->dir == NULL ){
            apagar_recursivo(&no);
            return NULL;
        }
    }

    return no;
}

AVL *avl_carregar(FILE *fp){
    if ( fp == NULL ) return NULL;

    int n_chaves;
    if ( fread(&n_chaves, sizeof(int), 1, fp) != 1 || n_chaves < 0 ) return NULL;

    AVL *t = avl_criar();
    if ( t == NULL ) return NULL;

    if ( n_chaves > 0 ){
        t->raiz = carregar_no(fp);
        if ( t->raiz == NULL ){
            avl_apagar(&t);
            return NULL;
        }
    }
    t->n_chaves = n_chaves;
    return t;
}