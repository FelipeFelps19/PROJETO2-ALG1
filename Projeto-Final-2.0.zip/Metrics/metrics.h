#ifndef METRICS_H
#define METRICS_H


typedef struct 
{
    long long input_records, indexed_records, distinct_keys, insert_comparisons,
    rotations, recolors;
    int tree_height;
    double build_ms, save_index_ms;
} buildmetrics;

typedef struct 
{
    long long output_records, matched_offsets, search_comparisons, query_keys;
    int index_count;
    double total_ms, write_ms, fetch_ms, search_ms, load_index_ms;
} searchmetrics;

double now_ms(void);
void print_buildmetrics(const char *tree, const char *key, const buildmetrics *m);
void print_searchmetrics(const searchmetrics *s);

#endif