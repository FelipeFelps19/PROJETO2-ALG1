#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "item_indice.h"

struct item_indice {
    char *chave; // chave de busca ( EX : 2028 ) , ou seja, ano 2028 de algum campo
    off_t *offsets; // salva os offsets dos itens que correspondem a chave
    int n_offsets; // indica o numero de offsets encontrados
    int capacidade; // indica a capacidade maxima do vetor de offsets
};

ITEM_INDICE *item_indice_criar(const char *chave, off_t offset){
    if ( chave == NULL ) return NULL;

    ITEM_INDICE *it = (ITEM_INDICE*) malloc(sizeof(ITEM_INDICE));
    if ( it == NULL ) return NULL;

    it->chave = strdup(chave);
    if ( it->chave == NULL ){
        free(it);
        return NULL;
    }
    it->capacidade = 4;

    it->offsets = (off_t*) malloc(it->capacidade * sizeof(off_t));
    if ( it->offsets == NULL ){
        free(it->chave);
        free(it);
        return NULL;
    }
    
    it->offsets[0] = offset;
    it->n_offsets = 1;
    return it;
}

void item_indice_apagar(ITEM_INDICE **item){
    if ( item == NULL || *item == NULL ) return;


    free((*item)->chave);
    free((*item)->offsets);
    free(*item);
    *item = NULL; 
}


bool item_indice_adicionar_offset(ITEM_INDICE *item, off_t offset){
    if ( item == NULL ) return false;

    // se chegar na capacidade maxima, dobra a capacidade
    if ( item->n_offsets >= item->capacidade ){
        int nova_capacidade = item->capacidade * 2;
        off_t *tmp = (off_t*) realloc(item->offsets,nova_capacidade * sizeof(off_t));
        if ( tmp == NULL ) return false;
        item->offsets = tmp;
        item->capacidade = nova_capacidade;
    }

    item->offsets[item->n_offsets] = offset;
    item->n_offsets++;
    return true;
}


const char *item_indice_get_chave(const ITEM_INDICE *item){
    if ( item == NULL ) return NULL;
    return item->chave;
}

int item_indice_get_n_offsets(const ITEM_INDICE *item){
    if ( item == NULL ) return -1;
    return item->n_offsets;
}

off_t item_indice_get_offset(const ITEM_INDICE *item, int i){
    if ( item == NULL || i < 0 || i >= item->n_offsets) return -1;
    return item->offsets[i];
}