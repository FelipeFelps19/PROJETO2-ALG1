#ifndef ITEM_INDICE_H
#define ITEM_INDICE_H

#include <stdbool.h>
#include <sys/types.h>   

typedef struct item_indice ITEM_INDICE;

// cria um item com uma copia da chave e o primeiro offset, devolve null se faltar memoria.
ITEM_INDICE *item_indice_criar(const char *chave, off_t offset);

// libera a chave, o vetor de offsets e o proprio item.
void item_indice_apagar(ITEM_INDICE **item);

// acrescenta um offset ao item, devolve false se faltar memoria.
bool item_indice_adicionar_offset(ITEM_INDICE *item, off_t offset);

// getters
const char *item_indice_get_chave(const ITEM_INDICE *item);
int item_indice_get_n_offsets(const ITEM_INDICE *item);
off_t item_indice_get_offset(const ITEM_INDICE *item, int i);

#endif