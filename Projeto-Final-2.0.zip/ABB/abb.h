#ifndef ABB_H
#define ABB_H

#include <stdio.h>
#include <stdbool.h>
#include <sys/types.h>
#include "../Item_indice/item_indice.h"

typedef struct abb ABB;

// Cria uma ABB vazia.
ABB *abb_criar(void);

// Apaga a árvore.
void abb_apagar(ABB **t);

// Insere o item na árvore.
bool abb_inserir(ABB *t, ITEM_INDICE *item);

// Procura a chave do 'item' e devolve o item da árvore com todos os offsets,
// Soma em *comparacoes (se não for NULL) as comparações de chave feitas.
const ITEM_INDICE *abb_buscar(const ABB *t, const ITEM_INDICE *item, long *comparacoes);

// Altura da árvore
int abb_altura(const ABB *t);

// Métricas da construção
int       abb_n_chaves(const ABB *t);      // DISTINCT_KEYS
long long abb_comparacoes(const ABB *t);   // INSERT_COMPARISONS
long long abb_rotacoes(const ABB *t);      // ROTATIONS (sempre 0 na ABB)
long long abb_trocas_cor(const ABB *t);    // RECOLORS (sempre 0 na ABB)

// Grava a árvore no arquivo, em pré-ordem, e a carrega de volta com a mesma forma
bool abb_salvar(const ABB *t, FILE *fp);
ABB *abb_carregar(FILE *fp);

#endif