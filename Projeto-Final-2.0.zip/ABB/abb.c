#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "abb.h"

typedef struct no{
    ITEM_INDICE *item;
    struct no* dir;
    struct no* esq;
}NO;

struct abb{
    NO* raiz;
    int n_chaves;
    long long comparacoes;
};

ABB *abb_criar(void){
    ABB * ab = (ABB*) malloc(sizeof(ABB));
    if ( ab == NULL ) return NULL;
    ab->raiz = NULL;
    ab->n_chaves = 0;
    ab->comparacoes = 0;
    return ab;
}

static void apagar_recursivo(NO **atual){
    if ( atual == NULL || *atual == NULL) return;

    apagar_recursivo(&(*atual)->dir);
    apagar_recursivo(&(*atual)->esq);

    item_indice_apagar(&(*atual)->item);
    free(*atual);
    *atual = NULL;
}

void abb_apagar(ABB **t){
    if ( t == NULL || *t == NULL) return;
    apagar_recursivo(&(*t)->raiz);
    free(*t);
    *t = NULL;
}

static NO* inserir_recursivo(NO* atual, ITEM_INDICE *item, ABB *t, bool *sucesso){
    if ( atual == NULL ){
        NO* novo = (NO*) malloc(sizeof(NO));
        if (novo == NULL) return NULL;
        novo->item = item;
        novo->dir = NULL;
        novo->esq = NULL;
        t->n_chaves++;
        *sucesso = true;
        return novo;
    }

    // retorna < 0 se a chave for menor, == 0 se a chave for igual e > 0 se for maior
    int cmp = strcmp(item_indice_get_chave(item), item_indice_get_chave(atual->item));
    t->comparacoes++;

    if ( cmp < 0 ) {
        atual->esq = inserir_recursivo(atual->esq,item,t,sucesso);
    }else if( cmp > 0 ) {
        atual->dir = inserir_recursivo(atual->dir,item,t,sucesso);
    }else{
        // chave repetida: passa os offsets do item novo para o item do nó
        int n = item_indice_get_n_offsets(item);
        for (int i = 0; i < n; i++){
            // adiciona os offsets do item ao item da arvore
            if ( !item_indice_adicionar_offset(atual->item,item_indice_get_offset(item,i)) ){
                return atual;   // faltou memória: sucesso continua false e o item continua do chamador
            }
        }
        item_indice_apagar(&item);
        *sucesso = true;
    }

    return atual;
}

bool abb_inserir(ABB *t, ITEM_INDICE *item){
    if ( t == NULL || item == NULL ) return false;
    bool sucesso = false;
    t->raiz = inserir_recursivo(t->raiz,item,t,&sucesso);
    return sucesso;
}


static ITEM_INDICE *buscar_recursivo( NO* atual, const char *chave, long *comparacoes ){
    if ( atual == NULL ) return NULL;

    // retorna < 0 se a chave for menor, == 0 se a chave for igual e > 0 se for maior
    int cmp = strcmp(chave, item_indice_get_chave(atual->item));
    if ( comparacoes != NULL ) (*comparacoes)++;

    if ( cmp == 0 ) {
        return atual->item;
    }else if ( cmp < 0 ){
        return buscar_recursivo(atual->esq,chave,comparacoes);
    }else{
        return buscar_recursivo(atual->dir,chave,comparacoes);
    }
}

const ITEM_INDICE *abb_buscar(const ABB *t, const ITEM_INDICE *item, long *comparacoes){
    if ( t == NULL || item == NULL ) return NULL;
    return buscar_recursivo(t->raiz,item_indice_get_chave(item),comparacoes);
}

static int verifica_altura_recursivo(NO *atual){
    if ( atual == NULL ) return -1;

    int altura_dir = verifica_altura_recursivo(atual->dir);
    int altura_esq = verifica_altura_recursivo(atual->esq);

    if ( altura_dir > altura_esq){
        return altura_dir + 1;
    }else{
        return altura_esq + 1;
    }
}

int abb_altura(const ABB *t){
    if ( t == NULL ) return -1;
    return verifica_altura_recursivo(t->raiz);
}

int abb_n_chaves(const ABB *t){
    if ( t == NULL ) return 0;
    return t->n_chaves;
}

long long abb_comparacoes(const ABB *t){
    if ( t == NULL ) return 0;
    return t->comparacoes;
}

long long abb_rotacoes(const ABB *t){
    (void) t;   // a ABB não faz rotações
    return 0;
}

long long abb_trocas_cor(const ABB *t){
    (void) t;   // a ABB não tem cores
    return 0;
}

static bool salvar_no(const NO *atual, FILE *fp){
    if ( atual == NULL ) return true;

    const char *chave = item_indice_get_chave(atual->item);
    int tam = (int) strlen(chave);
    int n = item_indice_get_n_offsets(atual->item);
    unsigned char tem_esq = ( atual->esq != NULL );
    unsigned char tem_dir = ( atual->dir != NULL );

    if ( fwrite(&tam, sizeof(int), 1, fp) != 1 ) return false;
    if ( fwrite(chave, 1, tam, fp) != (size_t) tam ) return false;
    if ( fwrite(&n, sizeof(int), 1, fp) != 1 ) return false;

    for (int i = 0; i < n; i++){
        long long off = (long long) item_indice_get_offset(atual->item, i);
        if ( fwrite(&off, sizeof(long long), 1, fp) != 1 ) return false;
    }

    if ( fwrite(&tem_esq, 1, 1, fp) != 1 ) return false;
    if ( fwrite(&tem_dir, 1, 1, fp) != 1 ) return false;

    return salvar_no(atual->esq, fp) && salvar_no(atual->dir, fp);
}

bool abb_salvar(const ABB *t, FILE *fp){
    if ( t == NULL || fp == NULL ) return false;
    if ( fwrite(&t->n_chaves, sizeof(int), 1, fp) != 1 ) return false;
    return salvar_no(t->raiz, fp);
}

static NO *carregar_no(FILE *fp){
    int tam, n;
    unsigned char tem_esq, tem_dir;

    if ( fread(&tam, sizeof(int), 1, fp) != 1 || tam < 0 ) return NULL;

    char *chave = (char*) malloc(tam + 1);
    if ( chave == NULL ) return NULL;

    if ( fread(chave, 1, tam, fp) != (size_t) tam ){
        free(chave);
        return NULL;
    }
    chave[tam] = '\0';

    if ( fread(&n, sizeof(int), 1, fp) != 1 || n < 1 ){
        free(chave);
        return NULL;
    }

    ITEM_INDICE *item = NULL;
    for (int i = 0; i < n; i++){
        long long off;
        bool ok = ( fread(&off, sizeof(long long), 1, fp) == 1 );

        if ( ok && i == 0 ){
            item = item_indice_criar(chave, (off_t) off);
            ok = ( item != NULL );
        }else if ( ok ){
            ok = item_indice_adicionar_offset(item, (off_t) off);
        }

        if ( !ok ){
            free(chave);
            if ( item != NULL ) item_indice_apagar(&item);
            return NULL;
        }
    }
    free(chave);

    NO *no = (NO*) malloc(sizeof(NO));
    if ( no == NULL ){
        item_indice_apagar(&item);
        return NULL;
    }
    no->item = item;
    no->esq = NULL;
    no->dir = NULL;

    if ( fread(&tem_esq, 1, 1, fp) != 1 || fread(&tem_dir, 1, 1, fp) != 1 ){
        apagar_recursivo(&no);
        return NULL;
    }

    if ( tem_esq ){
        no->esq = carregar_no(fp);
        if ( no->esq == NULL ){
            apagar_recursivo(&no);
            return NULL;
        }
    }
    if ( tem_dir ){
        no->dir = carregar_no(fp);
        if ( no->dir == NULL ){
            apagar_recursivo(&no);
            return NULL;
        }
    }

    return no;
}

ABB *abb_carregar(FILE *fp){
    if ( fp == NULL ) return NULL;

    int n_chaves;
    if ( fread(&n_chaves, sizeof(int), 1, fp) != 1 || n_chaves < 0 ) return NULL;

    ABB *t = abb_criar();
    if ( t == NULL ) return NULL;

    if ( n_chaves > 0 ){
        t->raiz = carregar_no(fp);
        if ( t->raiz == NULL ){
            abb_apagar(&t);
            return NULL;
        }
    }
    t->n_chaves = n_chaves;
    return t;
}