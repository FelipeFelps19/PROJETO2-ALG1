#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <sys/types.h>

#include "Metrics/metrics.h"
#include "Item_indice/item_indice.h"
#include "Indice/indice.h"
#include "Cabecalho/cabecalho.h"
#include "Reader_MEC/reader_mec.h"
#include "Reader_Nasa/reader_nasa.h"

#define MAX_INDICES 16

// Tudo o que veio da linha de comando
typedef struct {
    char *modo;
    char *reader;
    char *input;
    char *arvore;
    char *chave;
    char *query;
    char *output;
    long limit;
    char *indices[MAX_INDICES];
    int n_indices;
} ARGUMENTOS;

// As duas funções do reader escolhido (nasa ou MEC)
typedef struct {
    int (*indice_coluna)(FILE *fp, const char *nome_coluna);
    bool (*ler_chave)(FILE *fp, int idx_coluna, char *chave, int tam_chave, off_t *offset);
} READER;

// Vetor de offsets que cresce conforme as buscas acham registros
typedef struct {
    off_t *v; // vetor de offsets
    long long n; // numero de offsets usados
    long long cap; // capacidade total
} OFFSETS;


/* ---------- Declarações ---------- */

// Auxiliares
static int  erro(void);
static int  cmp_off(const void *a, const void *b);

// Argumentos e reader
static void ler_argumentos(int argc, char *argv[], ARGUMENTOS *a);
static bool escolher_reader(const char *nome, READER *r);

// Modo index
static int  modo_index(const ARGUMENTOS *a, const READER *r, FILE *fp);
static void construir_indice(FILE *fp, const READER *r, int idx_coluna, long limit,
                             INDICE *ind, buildmetrics *m);
static bool salvar_indice(const char *caminho_idx, const char *csv, const char *coluna,
                          const INDICE *ind);

// Modo search
static int  modo_search(const ARGUMENTOS *a, FILE *fp);
static bool carregar_indices(const ARGUMENTOS *a, INDICE *idx[], char colunas[][128]);
static void apagar_indices(INDICE *idx[], int n);
static bool executar_consultas(const char *query, INDICE *idx[], char colunas[][128],
                               int n_indices, OFFSETS *o, searchmetrics *s);
static int  achar_indice(const char *coluna, char colunas[][128], int n);
static bool offsets_adicionar(OFFSETS *o, off_t x);
static void remover_repetidos(OFFSETS *o);
static bool escrever_saida(const char *output, FILE *fp, const OFFSETS *o, searchmetrics *s);


/* ---------- main ---------- */

int main(int argc, char *argv[]){
    ARGUMENTOS a;
    ler_argumentos(argc, argv, &a);

    if ( a.modo == NULL || a.reader == NULL || a.input == NULL ) return erro();

    READER r;
    if ( !escolher_reader(a.reader, &r) ) return erro();

    // "rb" para os offsets baterem byte a byte
    FILE *fp = fopen(a.input, "rb");
    if ( fp == NULL ) return erro();

    int status;
    if ( strcmp(a.modo, "index") == 0 ){
        status = modo_index(&a, &r, fp);
    }else if ( strcmp(a.modo, "search") == 0 ){
        status = modo_search(&a, fp);
    }else{
        status = erro();
    }

    fclose(fp);
    return status;
}


/* ---------- Auxiliares ---------- */

static int erro(void){
    printf("STATUS=ERRO\n");
    return 1;
}

// Usado pelo qsort para ordenar os offsets
static int cmp_off(const void *a, const void *b){
    off_t x = *(const off_t *)a, y = *(const off_t *)b;
    return (x > y) - (x < y);
}

/* ---------- Argumentos e reader ---------- */

static void ler_argumentos(int argc, char *argv[], ARGUMENTOS *a){
    a->modo = NULL;
    a->reader = NULL;
    a->input = NULL;
    a->arvore = NULL;
    a->chave = NULL;
    a->query = NULL;
    a->output = NULL;
    a->limit = 0;
    a->n_indices = 0;

    // cada opção vem seguida do seu valor, por isso o ++i
    for (int i = 1; i + 1 < argc; i++){
        if      ( strcmp(argv[i], "--mode")   == 0 ) a->modo   = argv[++i];
        else if ( strcmp(argv[i], "--reader") == 0 ) a->reader = argv[++i];
        else if ( strcmp(argv[i], "--input")  == 0 ) a->input  = argv[++i];
        else if ( strcmp(argv[i], "--tree")   == 0 ) a->arvore = argv[++i];
        else if ( strcmp(argv[i], "--key")    == 0 ) a->chave  = argv[++i];
        else if ( strcmp(argv[i], "--query")  == 0 ) a->query  = argv[++i];
        else if ( strcmp(argv[i], "--output") == 0 ) a->output = argv[++i];
        else if ( strcmp(argv[i], "--limit")  == 0 ) a->limit  = atol(argv[++i]);
        else if ( strcmp(argv[i], "--index")  == 0 && a->n_indices < MAX_INDICES )
            a->indices[a->n_indices++] = argv[++i];
    }
}

static bool escolher_reader(const char *nome, READER *r){
    if ( strcmp(nome, "nasa") == 0 ){
        r->indice_coluna = reader_nasa_indice_coluna;
        r->ler_chave = reader_nasa_ler_chave;
        return true;
    }
    if ( strcmp(nome, "MEC") == 0 ){
        r->indice_coluna = reader_mec_indice_coluna;
        r->ler_chave = reader_mec_ler_chave;
        return true;
    }
    return false;
}


/* ---------- Modo index ---------- */

// Lê o CSV linha a linha e insere cada chave/offset na árvore
static void construir_indice(FILE *fp, const READER *r, int idx_coluna, long limit,
                             INDICE *ind, buildmetrics *m){
                                
    char chave_lida[256];
    off_t offset;
    long lidos = 0, indexados = 0;

    double t0 = now_ms();
    while ( (limit == 0 || lidos < limit) &&
            r->ler_chave(fp, idx_coluna, chave_lida, sizeof(chave_lida), &offset) ){
        lidos++;
        ITEM_INDICE *item = item_indice_criar(chave_lida, offset);
        if ( item != NULL && indice_inserir(ind, item) ){
            indexados++;
        }else{
            item_indice_apagar(&item);   // a árvore não ficou com ele
        }
    }
    m->build_ms = now_ms() - t0;

    m->input_records = lidos;
    m->indexed_records = indexados;
    m->distinct_keys = indice_n_chaves(ind);
    m->tree_height = indice_altura(ind);
    m->insert_comparisons = indice_comparacoes(ind);
    m->rotations = indice_rotacoes(ind);
    m->recolors = indice_trocas_cor(ind);
}

// Grava o cabeçalho e depois a árvore no arquivo .idx
static bool salvar_indice(const char *caminho_idx, const char *csv, const char *coluna,
                          const INDICE *ind){
    FILE *fp_idx = fopen(caminho_idx, "wb");
    if ( fp_idx == NULL ) return false;

    bool ok = cabecalho_salvar(fp_idx, csv, coluna) && indice_salvar(ind, fp_idx);
    fclose(fp_idx);

    return ok;
}

static int modo_index(const ARGUMENTOS *a, const READER *r, FILE *fp){
    if ( a->arvore == NULL || a->chave == NULL || a->n_indices == 0 ) return erro();

    int idx_coluna = r->indice_coluna(fp, a->chave);
    if ( idx_coluna < 0 ) return erro();   // coluna não existe no cabeçalho

    INDICE *ind = indice_criar(a->arvore);
    if ( ind == NULL ) return erro();      // nome de árvore inválido

    buildmetrics m = {0};
    construir_indice(fp, r, idx_coluna, a->limit, ind, &m);

    double t0 = now_ms();
    bool ok = salvar_indice(a->indices[0], a->input, a->chave, ind);
    m.save_index_ms = now_ms() - t0;

    indice_apagar(&ind);

    if ( !ok ) return erro();
    print_buildmetrics(a->arvore, a->chave, &m);
    return 0;
}


/* ---------- Modo search ---------- */

static void apagar_indices(INDICE *idx[], int n){
    for (int i = 0; i < n; i++) indice_apagar(&idx[i]);
}

// Carrega cada .idx e guarda a coluna que ele indexa (vem do cabeçalho)
static bool carregar_indices(const ARGUMENTOS *a, INDICE *idx[], char colunas[][128]){
    for (int i = 0; i < a->n_indices; i++){
        FILE *fp_idx = fopen(a->indices[i], "rb");
        CABECALHO *c = NULL;
        idx[i] = NULL;

        // o cabeçalho também confere se o CSV não mudou desde a indexação
        if ( fp_idx != NULL ) c = cabecalho_ler(fp_idx, a->input);
        if ( c != NULL ){
            idx[i] = indice_carregar(fp_idx);
            strcpy(colunas[i], cabecalho_get_coluna(c));
            cabecalho_apagar(&c);
        }
        if ( fp_idx != NULL ) fclose(fp_idx);

        if ( idx[i] == NULL ){
            apagar_indices(idx, i);
            return false;
        }
    }
    return true;
}

static bool offsets_adicionar(OFFSETS *o, off_t x){
    if ( o->n == o->cap ){
        long long nova = ( o->cap == 0 ) ? 16 : o->cap * 2;
        off_t *tmp = realloc(o->v, nova * sizeof(off_t));
        if ( tmp == NULL ) return false;
        o->v = tmp;
        o->cap = nova;
    }
    o->v[o->n++] = x;
    return true;
}

// Devolve qual dos índices carregados indexa essa coluna, ou -1
static int achar_indice(const char *coluna, char colunas[][128], int n){
    for (int i = 0; i < n; i++){
        if ( strcmp(colunas[i], coluna) == 0 ) return i;
    }
    return -1;
}

// Lê cada linha "KEY|coluna|valor", busca na árvore certa e junta os offsets
static bool executar_consultas(const char *query, INDICE *idx[], char colunas[][128],
                               int n_indices, OFFSETS *o, searchmetrics *s){
    FILE *fq = fopen(query, "r");
    if ( fq == NULL ) return false;

    char linha[512];
    bool ok = true;

    while ( ok && fgets(linha, sizeof(linha), fq) != NULL ){
        linha[strcspn(linha, "\r\n")] = '\0';
        if ( linha[0] == '\0' ) continue;

        char *tipo   = strtok(linha, "|");
        char *coluna = strtok(NULL, "|");
        char *valor  = strtok(NULL, "|");
        if ( tipo == NULL || coluna == NULL || valor == NULL ) continue;

        s->query_keys++;

        int k = achar_indice(coluna, colunas, n_indices);
        if ( k < 0 ){ ok = false; break; }   // coluna sem índice carregado

        ITEM_INDICE *consulta = item_indice_criar(valor, -1);
        if ( consulta == NULL ){ ok = false; break; }

        long comps = 0;
        double t0 = now_ms();
        const ITEM_INDICE *achado = indice_buscar(idx[k], consulta, &comps);
        s->search_ms += now_ms() - t0;   // só o tempo dentro da árvore
        s->search_comparisons += comps;

        item_indice_apagar(&consulta);

        if ( achado != NULL ){
            int n = item_indice_get_n_offsets(achado);
            for (int j = 0; j < n && ok; j++){
                ok = offsets_adicionar(o, item_indice_get_offset(achado, j));
            }
        }
    }

    fclose(fq);
    s->matched_offsets = o->n;
    return ok;
}

// Ordena e tira repetidos
static void remover_repetidos(OFFSETS *o){
    if ( o->n < 2 ) return;

    qsort(o->v, o->n, sizeof(off_t), cmp_off);

    long long w = 1;
    for (long long i = 1; i < o->n; i++){
        if ( o->v[i] != o->v[w - 1] ) o->v[w++] = o->v[i];
    }
    o->n = w;
}

// Copia o cabeçalho e depois cada registro, lendo um por vez pelo offset
static bool escrever_saida(const char *output, FILE *fp, const OFFSETS *o, searchmetrics *s){
    FILE *out = fopen(output, "wb");
    if ( out == NULL ) return false;

    char registro[4096];

    fseeko(fp, 0, SEEK_SET);
    if ( fgets(registro, sizeof(registro), fp) != NULL ) fputs(registro, out);

    for (long long i = 0; i < o->n; i++){
        double t0 = now_ms();
        fseeko(fp, o->v[i], SEEK_SET);
        char *lido = fgets(registro, sizeof(registro), fp);
        s->fetch_ms += now_ms() - t0;

        if ( lido == NULL ) continue;

        t0 = now_ms();
        fputs(registro, out);
        s->write_ms += now_ms() - t0;
    }

    fclose(out);
    return true;
}

static int modo_search(const ARGUMENTOS *a, FILE *fp){
    if ( a->n_indices == 0 || a->query == NULL || a->output == NULL ) return erro();

    searchmetrics s = {0};
    double t_total = now_ms();

    INDICE *idx[MAX_INDICES];
    char colunas[MAX_INDICES][128];

    double t0 = now_ms();
    if ( !carregar_indices(a, idx, colunas) ) return erro();
    s.load_index_ms = now_ms() - t0;
    s.index_count = a->n_indices;

    OFFSETS o = { NULL, 0, 0 };
    bool ok = executar_consultas(a->query, idx, colunas, a->n_indices, &o, &s);

    if ( ok ){
        remover_repetidos(&o);
        s.output_records = o.n;
        ok = escrever_saida(a->output, fp, &o, &s);
    }

    free(o.v);
    apagar_indices(idx, a->n_indices);

    if ( !ok ) return erro();

    s.total_ms = now_ms() - t_total;
    print_searchmetrics(&s);
    return 0;
}