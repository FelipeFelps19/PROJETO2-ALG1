#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "rubro-negra.h"

#define VERMELHO 0
#define PRETO    1

typedef struct no{
    ITEM_INDICE *item;
    int cor;
    int altura;
    struct no* dir;
    struct no* esq;
}NO;

struct arb{
    NO* raiz;
    int n_chaves;
    long long rotacao;
    long long comparacoes;
    long long alteracores;
};

ARB *arb_criar(void){
    ARB *arn = (ARB*) malloc(sizeof(ARB));
    if ( arn == NULL ) return NULL;
    arn->raiz = NULL;
    arn->n_chaves = 0;
    arn->rotacao = 0;
    arn->comparacoes = 0;
    arn->alteracores = 0;
    return arn;
}

static void apagar_recursivo(NO **atual){
    if ( atual == NULL || *atual == NULL) return;

    apagar_recursivo(&(*atual)->dir);
    apagar_recursivo(&(*atual)->esq);

    item_indice_apagar(&(*atual)->item);

    free(*atual);
    *atual = NULL;
}

void arb_apagar(ARB **t){
    if ( t == NULL || *t == NULL) return;
    apagar_recursivo(&(*t)->raiz);
    free(*t);
    *t = NULL;
}

static int altura(NO *A){
    if ( A == NULL ) return -1;
    return A->altura;
}

static int atualizar_altura(NO *A){
    if ( A == NULL ) return -1;

    int altura_esq = altura(A->esq);
    int altura_dir = altura(A->dir);

    return ( altura_esq > altura_dir ? altura_esq : altura_dir ) + 1;
}

static void definir_cor(NO *no, int cor, ARB *arn){
    if ( no != NULL && no->cor != cor ){
        no->cor = cor;
        arn->alteracores++;
    }
}

static NO *rotacao_dir(NO *A, ARB *arn){
    NO *B = A->esq;
    NO *T = B->dir;

    B->dir = A;
    A->esq = T;

    definir_cor(B, A->cor, arn);
    definir_cor(A, VERMELHO, arn);

    A->altura = atualizar_altura(A);
    B->altura = atualizar_altura(B);

    arn->rotacao++;

    return B;
}

static NO *rotacao_esq(NO *A, ARB *arn){
    NO *B = A->dir;
    NO *T = B->esq;

    B->esq = A;
    A->dir = T;

    definir_cor(B, A->cor, arn);
    definir_cor(A, VERMELHO, arn);

    A->altura = atualizar_altura(A);
    B->altura = atualizar_altura(B);

    arn->rotacao++;

    return B;
}

static void inversao_de_cores(NO *A, ARB *arn){
    if ( A == NULL || A->esq == NULL || A->dir == NULL ) return;
    definir_cor(A, !(A->cor), arn);
    definir_cor(A->dir, !(A->dir->cor), arn);
    definir_cor(A->esq, !(A->esq->cor), arn);
}

static int verifica_cor(NO *A){
    if ( A == NULL ) return PRETO;
    return A->cor;
}

static NO *inserir_recursivo(NO *atual, ITEM_INDICE *item, bool *sucesso, ARB *arn){
    if ( atual == NULL ){
        NO* novo = (NO*) malloc(sizeof(NO));
        if (novo == NULL) return NULL;
        novo->item = item;
        novo->cor = VERMELHO;
        novo->altura = 0;
        novo->dir = NULL;
        novo->esq = NULL;
        arn->n_chaves++;
        *sucesso = true;
        return novo;
    } 

    int cmp = strcmp(item_indice_get_chave(item), item_indice_get_chave(atual->item));
    arn->comparacoes++;

    if ( cmp < 0 ) {
        atual->esq = inserir_recursivo(atual->esq, item, sucesso, arn);
    }else if( cmp > 0 ) {
        atual->dir = inserir_recursivo(atual->dir, item, sucesso, arn);
    }else{
        int n = item_indice_get_n_offsets(item);
        for(int i = 0; i < n; i++){
            if ( !item_indice_adicionar_offset(atual->item, item_indice_get_offset(item, i)) ){
                *sucesso = false; 
                return atual;
            }
        }
        item_indice_apagar(&item);  
        *sucesso = true;
        return atual; 
    }

    atual->altura = atualizar_altura(atual);

    if ( *sucesso ){
        if ( verifica_cor(atual->dir) == VERMELHO && verifica_cor(atual->esq) == PRETO ){
            atual = rotacao_esq(atual, arn);
        }

        if ( verifica_cor(atual->esq) == VERMELHO && verifica_cor(atual->esq->esq) == VERMELHO ){
            atual = rotacao_dir(atual, arn);
        }

        if ( verifica_cor(atual->esq) == VERMELHO && verifica_cor(atual->dir) == VERMELHO ){
            inversao_de_cores(atual, arn);
        }
    }

    return atual;
}

bool arb_inserir(ARB *t, ITEM_INDICE *item){
    if ( t == NULL || item == NULL ) return false;
    bool sucesso = false;
    t->raiz = inserir_recursivo(t->raiz, item, &sucesso, t);
    if ( t->raiz != NULL ) definir_cor(t->raiz, PRETO, t);
    return sucesso;
}

static void imprimir_recursivo(const NO *atual){
    if ( atual == NULL ) return;

    imprimir_recursivo(atual->esq);

    printf("%s:", item_indice_get_chave(atual->item));
    int n = item_indice_get_n_offsets(atual->item);
    for (int i = 0; i < n; i++){
        printf(" %lld", (long long) item_indice_get_offset(atual->item, i));
    }
    printf("\n");

    imprimir_recursivo(atual->dir);
}

void arb_imprimir(const ARB *t){
    if ( t == NULL ) return;
    imprimir_recursivo(t->raiz);
}

const ITEM_INDICE *arb_buscar(const ARB *t, const ITEM_INDICE *item, long *comparacoes){
    if ( t == NULL || item == NULL ) return NULL;

    const char *chave = item_indice_get_chave(item);
    const NO *atual = t->raiz;

    while ( atual != NULL ){
        int cmp = strcmp(chave, item_indice_get_chave(atual->item));
        if ( comparacoes != NULL ) (*comparacoes)++;

        if ( cmp == 0 ) return atual->item;
        atual = ( cmp < 0 ) ? atual->esq : atual->dir;
    }

    return NULL;
}


int arb_altura(const ARB *t){
    if ( t == NULL ) return -1;
    return altura(t->raiz);
}

int arb_n_chaves(const ARB *t){
    if ( t == NULL ) return 0;
    return t->n_chaves;
}

long long arb_comparacoes(const ARB *t){
    if ( t == NULL ) return 0;
    return t->comparacoes;
}

long long arb_rotacoes(const ARB *t){
    if ( t == NULL ) return 0;
    return t->rotacao;
}

long long arb_trocas_cor(const ARB *t){
    if ( t == NULL ) return 0;
    return t->alteracores;
}

static bool salvar_no(const NO *atual, FILE *fp){
    if ( atual == NULL ) return true;

    const char *chave = item_indice_get_chave(atual->item);
    int tam = (int) strlen(chave);
    int n = item_indice_get_n_offsets(atual->item);
    int cor = atual->cor;
    int alt = atual->altura;
    unsigned char tem_esq = ( atual->esq != NULL );
    unsigned char tem_dir = ( atual->dir != NULL );

    if ( fwrite(&tam, sizeof(int), 1, fp) != 1 ) return false;
    if ( fwrite(chave, 1, tam, fp) != (size_t) tam ) return false;
    if ( fwrite(&n, sizeof(int), 1, fp) != 1 ) return false;

    for (int i = 0; i < n; i++){
        long long off = (long long) item_indice_get_offset(atual->item, i);
        if ( fwrite(&off, sizeof(long long), 1, fp) != 1 ) return false;
    }

    if ( fwrite(&cor, sizeof(int), 1, fp) != 1 ) return false;
    if ( fwrite(&alt, sizeof(int), 1, fp) != 1 ) return false;
    if ( fwrite(&tem_esq, 1, 1, fp) != 1 ) return false;
    if ( fwrite(&tem_dir, 1, 1, fp) != 1 ) return false;

    return salvar_no(atual->esq, fp) && salvar_no(atual->dir, fp);
}

bool arb_salvar(const ARB *t, FILE *fp){
    if ( t == NULL || fp == NULL ) return false;
    if ( fwrite(&t->n_chaves, sizeof(int), 1, fp) != 1 ) return false;
    return salvar_no(t->raiz, fp);
}

static NO *carregar_no(FILE *fp){
    int tam, n, cor, alt;
    unsigned char tem_esq, tem_dir;

    if ( fread(&tam, sizeof(int), 1, fp) != 1 || tam < 0 ) return NULL;

    char *chave = (char*) malloc(tam + 1);
    if ( chave == NULL ) return NULL;

    if ( fread(chave, 1, tam, fp) != (size_t) tam ){
        free(chave);
        return NULL;
    }
    chave[tam] = '\0';

    if ( fread(&n, sizeof(int), 1, fp) != 1 || n < 1 ){
        free(chave);
        return NULL;
    }

    ITEM_INDICE *item = NULL;
    for (int i = 0; i < n; i++){
        long long off;
        bool ok = ( fread(&off, sizeof(long long), 1, fp) == 1 );

        if ( ok && i == 0 ){
            item = item_indice_criar(chave, (off_t) off);
            ok = ( item != NULL );
        }else if ( ok ){
            ok = item_indice_adicionar_offset(item, (off_t) off);
        }

        if ( !ok ){
            free(chave);
            if ( item != NULL ) item_indice_apagar(&item);
            return NULL;
        }
    }
    free(chave);

    if ( fread(&cor, sizeof(int), 1, fp) != 1 ||
         fread(&alt, sizeof(int), 1, fp) != 1 ||
         fread(&tem_esq, 1, 1, fp) != 1 ||
         fread(&tem_dir, 1, 1, fp) != 1 ){
        item_indice_apagar(&item);
        return NULL;
    }

    NO *no = (NO*) malloc(sizeof(NO));
    if ( no == NULL ){
        item_indice_apagar(&item);
        return NULL;
    }
    no->item = item;
    no->cor = cor;
    no->altura = alt;
    no->esq = NULL;
    no->dir = NULL;

    if ( tem_esq ){
        no->esq = carregar_no(fp);
        if ( no->esq == NULL ){
            apagar_recursivo(&no);
            return NULL;
        }
    }
    if ( tem_dir ){
        no->dir = carregar_no(fp);
        if ( no->dir == NULL ){
            apagar_recursivo(&no);
            return NULL;
        }
    }

    return no;
}

ARB *arb_carregar(FILE *fp){
    if ( fp == NULL ) return NULL;

    int n_chaves;
    if ( fread(&n_chaves, sizeof(int), 1, fp) != 1 || n_chaves < 0 ) return NULL;

    ARB *t = arb_criar();
    if ( t == NULL ) return NULL;

    if ( n_chaves > 0 ){
        t->raiz = carregar_no(fp);
        if ( t->raiz == NULL ){
            arb_apagar(&t);
            return NULL;
        }
    }
    t->n_chaves = n_chaves;
    return t;
}