#ifndef ARB_H
#define ARB_H

#include <stdio.h>
#include <stdbool.h>
#include <sys/types.h>  
#include "../Item_indice/item_indice.h"

typedef struct arb ARB;

// cria uma arvore rubro-negra vazia, devolve null se faltar memoria.
ARB *arb_criar(void);

// libera todos os nos, seus itens e a propria arvore, deixa t = null.
void arb_apagar(ARB **t);

// insere o item, mantendo as propriedades rubro-negras por rotacoes e trocas de cor,
// se a chave ja existe, os offsets vao para o item do no e o item e liberado,
// devolve false se faltar memoria, e o item continua sendo seu.
bool arb_inserir(ARB *t, ITEM_INDICE *item);

/* procura a chave do item e devolve o item da arvore com todos os offsets,
 ou null se nao existir, so a chave e usada,
 soma em comparacoes as comparacoes de chave feitas.
*/
const ITEM_INDICE *arb_buscar(const ARB *t, const ITEM_INDICE *item, long *comparacoes);

// altura da arvore, vazia = -1, so a raiz = 0.
int arb_altura(const ARB *t);

// imprime as chaves em ordem, cada uma com seus offsets, para depuracao.
void arb_imprimir(const ARB *t);

// metricas da construcao
int  arb_n_chaves(const ARB *t);           // distinct_keys
long long arb_comparacoes(const ARB *t);   // Número de Comparações
long long arb_rotacoes(const ARB *t);      // Número de Rotações
long long arb_trocas_cor(const ARB *t);    // Número de colorações

// grava a arvore no arquivo, preservando topologia, cores e alturas, devolve false em erro.
bool arb_salvar(const ARB *t, FILE *fp);

// le uma arvore gravada por arb_salvar, devolve null em erro ou se faltar memoria.
ARB *arb_carregar(FILE *fp);

#endif