#ifndef CABECALHO_H
#define CABECALHO_H

#include <stdio.h>
#include <stdbool.h>

// Informações gravadas no começo do arquivo .idx
typedef struct cabecalho CABECALHO;

// Monta o cabeçalho a partir do CSV e grava no .idx
bool cabecalho_salvar(FILE *fp_idx, const char *caminho_csv, const char *coluna);

// Lê o cabeçalho do .idx e confere se o CSV não mudou de tamanho desde a indexação.
// Devolve NULL se a leitura falhar ou se o CSV tiver mudado.
CABECALHO *cabecalho_ler(FILE *fp_idx, const char *caminho_csv);

// Libera o cabeçalho.
void cabecalho_apagar(CABECALHO **c);

// Getters
const char *cabecalho_get_coluna(const CABECALHO *c);
const char *cabecalho_get_tipo_chave(const CABECALHO *c);
long long cabecalho_get_tamanho_csv(const CABECALHO *c);

#endif