
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include <sys/types.h>
#include "cabecalho.h"
 
struct cabecalho {
    char coluna[128];       // coluna indexada
    char tipo_chave[16];    // sempre "texto"
    long long tamanho_csv;  // tamanho do CSV
};
 
// Devolve o tamanho do arquivo em bytes, ou -1 se ele não existir
static long long tamanho_arquivo(const char *caminho){
    FILE *fp = fopen(caminho, "rb");
    if ( fp == NULL ) return -1;
 
    fseeko(fp, 0, SEEK_END);       // pula para o fim do arquivo
    long long tam = ftello(fp);    // a posição do fim é o tamanho
    fclose(fp);
 
    return tam;
}
 
bool cabecalho_salvar(FILE *fp_idx, const char *caminho_csv, const char *coluna){
    long long tam = tamanho_arquivo(caminho_csv);
    if ( tam < 0 ) return false;   // CSV não existe
 
    CABECALHO c = {0};   // começa tudo zerado
    strncpy(c.coluna, coluna, sizeof(c.coluna) - 1);
    strcpy(c.tipo_chave, "texto");
    c.tamanho_csv = tam;
 
    return fwrite(&c, sizeof(CABECALHO), 1, fp_idx) == 1;
}
 
CABECALHO *cabecalho_ler(FILE *fp_idx, const char *caminho_csv){
    CABECALHO *c = (CABECALHO*) malloc(sizeof(CABECALHO));
    if ( c == NULL ) return NULL;
 
    if ( fread(c, sizeof(CABECALHO), 1, fp_idx) != 1 ){
        free(c);
        return NULL;
    }
 
    // se o CSV mudou de tamanho depois da indexação, o índice não vale mais
    if ( tamanho_arquivo(caminho_csv) != c->tamanho_csv ){
        free(c);
        return NULL;
    }
 
    return c;
}
 
void cabecalho_apagar(CABECALHO **c){
    if ( c == NULL || *c == NULL ) return;
    free(*c);
    *c = NULL;
}
 
const char *cabecalho_get_coluna(const CABECALHO *c){
    if ( c == NULL ) return NULL;
    return c->coluna;
}
 
const char *cabecalho_get_tipo_chave(const CABECALHO *c){
    if ( c == NULL ) return NULL;
    return c->tipo_chave;
}
 
long long cabecalho_get_tamanho_csv(const CABECALHO *c){
    if ( c == NULL ) return -1;
    return c->tamanho_csv;
}
 