#ifndef READER_NASA_H
#define READER_NASA_H

#include <stdbool.h>

// le a primeira linha, cabecalho, e devolve a posicao da coluna nome_coluna, 0, 1, 2, ..., ou -1 se ela nao existir.
// depois da chamada, o arquivo fica posicionado na primeira linha de dados.
int reader_nasa_indice_coluna(FILE *fp, const char *nome_coluna);

// le o proximo registro, pulando linhas vazias, copia para chave o valor da coluna idx_coluna, vazio se o campo estiver vazio ou ausente,
// e para offset o byte onde a linha comeca, devolve false no fim do arquivo ou em erro.
bool reader_nasa_ler_chave(FILE *fp, int idx_coluna, char *chave, int tam_chave, off_t *offset);

#endif