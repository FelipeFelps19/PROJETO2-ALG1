#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include <sys/types.h>

#include "Metrics/metrics.h"
#include "Item_indice/item_indice.h"
#include "Indice/indice.h"
#include "Cabecalho/cabecalho.h"
#include "ABB/abb.h"
#include "AVL/avl.h"
#include "Rubro_negra/rubro-negra.h"
#include "Reader_MEC/reader_mec.h"
#include "Reader_Nasa/reader_nasa.h"


static int cmp_off(const void *a, const void *b){
    off_t x = *(const off_t *)a, y = *(const off_t *)b;
    return (x > y) - (x < y);
}


int main(int argc, char *argv[]){
    char *modo = NULL;
    char *reader = NULL;
    char *input = NULL;
    char *arvore = NULL;
    char *chave = NULL;
    char *query = NULL;
    char *output = NULL;
    long limit = 0;

    char *indices[16];
    int n_indices = 0;

    for (int i = 1; i < argc; i++){
        if      ( strcmp(argv[i], "--mode")   == 0 ) modo   = argv[++i];
        else if ( strcmp(argv[i], "--reader") == 0 ) reader = argv[++i];
        else if ( strcmp(argv[i], "--input")  == 0 ) input  = argv[++i];
        else if ( strcmp(argv[i], "--tree")   == 0 ) arvore = argv[++i];
        else if ( strcmp(argv[i], "--key")    == 0 ) chave  = argv[++i];
        else if ( strcmp(argv[i], "--query")  == 0 ) query  = argv[++i];
        else if ( strcmp(argv[i], "--output") == 0 ) output = argv[++i];
        else if ( strcmp(argv[i], "--limit")  == 0 ) limit  = atol(argv[++i]);
        else if ( strcmp(argv[i], "--index")  == 0 && n_indices < 16 ) indices[n_indices++] = argv[++i];
    }
    
    if ( modo == NULL || reader == NULL || input == NULL ){
        printf("STATUS=ERRO\n");
        return 1;
    }


    int (*reader_indice_coluna)(FILE *fp, const char *nome_coluna);
    bool (*reader_ler_chave)(FILE *fp, int idx_coluna, char *chave, int tam_chave, off_t *offset);

    if ( strcmp (reader,"nasa") == 0){
        reader_indice_coluna = reader_nasa_indice_coluna;
        reader_ler_chave = reader_nasa_ler_chave;
    }else if (strcmp(reader,"MEC") == 0){
        reader_indice_coluna = reader_mec_indice_coluna;
        reader_ler_chave = reader_mec_ler_chave;
    }else{
        printf("STATUS=ERRO\n");
        return 1;
    }

    FILE *fp = fopen(input,"rb");
    if ( fp == NULL ) {
        printf("STATUS=ERRO\n");
        return 1;
    }


    if ( strcmp(modo, "index") == 0){
        buildmetrics m = {0};
        INDICE *ind = NULL;
        int status = 1;

        if ( arvore == NULL || chave == NULL || n_indices == 0){
            printf("STATUS=ERRO\n");
            return 1;
        }
        int indice_coluna = reader_indice_coluna(fp,chave);

        if (indice_coluna < 0){
            printf("STATUS=ERRO\n");
            return 1;
        }

        ind = indice_criar(arvore);
        if ( ind == NULL ){
            printf("STATUS=ERRO\n");
            return 1;
        }

        char chave_lida[256];
        off_t offset;
        long lidos = 0, indexados = 0;

        
        // Construção:

        double t0 = now_ms();
        while( (limit == 0 || lidos < limit) && reader_ler_chave(fp, indice_coluna, chave_lida,sizeof(chave_lida),&offset)){
            lidos++;
            ITEM_INDICE *item = item_indice_criar(chave_lida, offset);
            if ( item != NULL && indice_inserir(ind, item) ){
                indexados++;
            }else{
                item_indice_apagar(&item);
            }
        }
        
        m.build_ms = now_ms() - t0;
        m.input_records = lidos;
        m.indexed_records = indexados;
        m.distinct_keys = indice_n_chaves(ind);
        m.tree_height = indice_altura(ind);
        m.insert_comparisons = indice_comparacoes(ind);
        m.rotations = indice_rotacoes(ind);
        m.recolors = indice_trocas_cor(ind);

        t0 = now_ms();

        FILE *fp_idx = fopen(indices[0],"wb");
        bool ok = ( fp_idx != NULL ) && (cabecalho_salvar(fp_idx,input,chave)) && (indice_salvar(ind,fp_idx)); // Salva os dados da arvore em um arquivo indicado por index
        if ( fp_idx != NULL ) fclose(fp_idx);
        
        m.save_index_ms = now_ms() - t0;        

        if(ok) {
            print_buildmetrics(arvore, chave, &m);
            status = 0;
        } else printf("STATUS=ERRO\n");

        indice_apagar(&ind);
        fclose(fp);
        return status;

    }else if ( strcmp(modo, "search") == 0 ){
        searchmetrics s = {0};
        double t_total = now_ms(), t0;

        if ( n_indices == 0 || query == NULL || output == NULL ){
            printf("STATUS=ERRO\n");
            return 1;
        }

        // 1. Carregar os índices

        INDICE *idx[16];
        char colunas[16][128];

        t0 = now_ms();
        for (int i = 0; i < n_indices; i++){
            FILE *fp_idx = fopen(indices[i],"rb");
            if ( fp_idx == NULL ){
                printf("STATUS=ERRO\n");
                return 1;
            }

            CABECALHO *c = cabecalho_ler(fp_idx,input);
            if ( c == NULL ){
                printf("STATUS=ERRO\n");
                fclose(fp_idx);
                return 1;
            }

            idx[i] = indice_carregar(fp_idx);
            if ( idx[i] == NULL ){
                printf("STATUS=ERRO\n");
                fclose(fp_idx);
                cabecalho_apagar(&c);
                return 1;
            }

            strcpy(colunas[i],cabecalho_get_coluna(c));
            cabecalho_apagar(&c);

            fclose(fp_idx);
        }
        s.load_index_ms = now_ms() - t0;
        s.index_count = n_indices;

        // 2. Ler as consultas e buscar cada chave na árvore da sua coluna

        off_t *offsets = malloc(16 * sizeof(off_t));
        if ( offsets == NULL ){
            printf("STATUS=ERRO\n");
            return 1;
        }
        long long n_offsets = 0, cap_offsets = 16;

        FILE *fq = fopen(query, "r");
        if ( fq == NULL ){
            printf("STATUS=ERRO\n");
            return 1;
        }

        char linha[512];
        while ( fgets(linha, sizeof(linha), fq) != NULL ){
            linha[strcspn(linha, "\r\n")] = '\0';
            if ( linha[0] == '\0' ) continue;

            char *tipo   = strtok(linha, "|");   
            char *coluna = strtok(NULL, "|");    
            char *valor  = strtok(NULL, "|");    
            if ( tipo == NULL || coluna == NULL || valor == NULL ) continue;

            s.query_keys++;

            // acha o índice dessa coluna
            int k = -1;
            for (int i = 0; i < n_indices; i++){
                if ( strcmp(colunas[i], coluna) == 0 ){
                    k = i;
                    break;
                }
            }
            if ( k < 0 ){   // consulta numa coluna sem índice
                printf("STATUS=ERRO\n");
                return 1;
            }

            ITEM_INDICE *consulta = item_indice_criar(valor, -1);

            long comps = 0;
            t0 = now_ms();
            const ITEM_INDICE *achado = indice_buscar(idx[k], consulta, &comps);
            s.search_ms += now_ms() - t0;     // só o tempo da busca na árvore
            s.search_comparisons += comps;

            item_indice_apagar(&consulta);

            // guarda os offsets encontrados
            if ( achado != NULL ){
                int n = item_indice_get_n_offsets(achado);
                for (int j = 0; j < n; j++){
                    if ( n_offsets == cap_offsets ){
                        cap_offsets *= 2;   
                        off_t *tmp = realloc(offsets, cap_offsets * sizeof(off_t));
                        if ( tmp == NULL ){
                            printf("STATUS=ERRO\n");
                            return 1;
                        }
                        offsets = tmp;
                    }
                    offsets[n_offsets++] = item_indice_get_offset(achado, j);
                }
            }
        }
        fclose(fq);
        s.matched_offsets = n_offsets;

        // 3. Remover offsets repetidos: ordena e mantém só o primeiro de cada sequência igual

        if ( n_offsets > 1 ){
            qsort(offsets, n_offsets, sizeof(off_t), cmp_off);
            long long w = 1;
            for (long long i = 1; i < n_offsets; i++){
                if ( offsets[i] != offsets[w - 1] ) offsets[w++] = offsets[i];
            }
            n_offsets = w;
        }
        s.output_records = n_offsets;

        // 4. Ler cada registro pelo offset e escrever na saída, um de cada vez

        FILE *out = fopen(output, "wb");
        if ( out == NULL ){
            printf("STATUS=ERRO\n");
            return 1;
        }

        char registro[4096];

        // copia o cabeçalho do CSV
        fseeko(fp, 0, SEEK_SET);
        if ( fgets(registro, sizeof(registro), fp) != NULL ) fputs(registro, out);

        for (long long i = 0; i < n_offsets; i++){
            t0 = now_ms();
            fseeko(fp, offsets[i], SEEK_SET);
            char *lido = fgets(registro, sizeof(registro), fp);
            s.fetch_ms += now_ms() - t0;

            if ( lido == NULL ) continue;

            t0 = now_ms();
            fputs(registro, out);
            s.write_ms += now_ms() - t0;
        }
        fclose(out);

        s.total_ms = now_ms() - t_total;
        print_searchmetrics(&s);

        free(offsets);
        for (int j = 0; j < n_indices; j++) indice_apagar(&idx[j]);
        fclose(fp);
        return 0;

    }else{
        printf("STATUS=ERRO\n");
        return 1;
    }

    fclose(fp);
    return 0;
}