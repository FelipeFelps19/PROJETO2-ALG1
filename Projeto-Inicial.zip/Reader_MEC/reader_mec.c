#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "reader_mec.h"

// Extrai o próximo campo da linha, tratando aspas e vírgulas internas.
// As aspas são removidas do campo.
static char *extrair_proximo_campo(char **ptr){
    char *inicio = *ptr;
    char *leitura = inicio;
    char *escrita = inicio;
    bool aspas = false;

    while (*leitura != '\0'){
        if (*leitura == '"'){
            aspas = !aspas;
        }else if (*leitura == ',' && !aspas){
            *escrita = '\0';
            *ptr = leitura + 1;
            return inicio;
        }else{
            *escrita = *leitura;
            escrita++;
        }
        leitura++;
    }

    *escrita = '\0';
    *ptr = leitura;
    return inicio;
}

int reader_mec_indice_coluna(FILE *fp, const char *nome_coluna){
    if (fp == NULL || nome_coluna == NULL) return -1;

    char linha[2048];
    if (fgets(linha, sizeof(linha), fp) == NULL) return -1;
    linha[strcspn(linha,"\r\n")] = '\0';

    int idx = 0;
    char *campo;
    campo = strtok(linha,",");

    while(campo != NULL){
        if (strcmp(campo,nome_coluna) == 0){
            return idx;
        }
        campo = strtok(NULL,",");
        idx++;
    }

    return -1;
}

bool reader_mec_ler_chave(FILE *fp, int idx_coluna,char *chave, int tam_chave, off_t *offset){
    if (fp == NULL || chave == NULL || offset == NULL || idx_coluna < 0) return false;

    off_t pos = ftello(fp);

    char linha[2048];
    if (fgets(linha, sizeof(linha), fp) == NULL) return false;
    linha[strcspn(linha,"\r\n")] = '\0';

    char *inicio = linha;
    char *campo = NULL;

    for (int i = 0; i <= idx_coluna; i++){
        campo = extrair_proximo_campo(&inicio);
    }

    strncpy(chave,campo,tam_chave - 1);
    chave[tam_chave - 1] = '\0';

    *offset = pos;
    return true;
}