#ifndef AVL_H
#define AVL_H

#include <stdbool.h>

typedef struct avl AVL;

AVL *avl_criar(void);
void avl_apagar(AVL **t);
bool avl_inserir(AVL *t, int chave);
void avl_imprimir(const AVL *t);
bool avl_buscar(const AVL *t, int chave);
bool avl_remover(AVL *t, int chave);
int avl_altura(const AVL *t);

#endif