#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "avl.h"

typedef struct no {
    int chave;
    int altura;
    struct no *dir;
    struct no *esq;
} NO;

struct avl {
    NO *raiz;
};

AVL *avl_criar(void){
    AVL* t = (AVL*) malloc(sizeof(AVL));
    if ( t == NULL ) return NULL;
    t->raiz = NULL;
    return t;
}

void apagar_recursivo(NO **atual){
    if ( atual == NULL || *atual == NULL ) return;

    apagar_recursivo(&(*atual)->esq);
    apagar_recursivo(&(*atual)->dir);

    free(*atual);
    *atual = NULL;
}

void avl_apagar(AVL **t){
    if (t == NULL || *t == NULL) return;
    apagar_recursivo(&(*t)->raiz);
    free(*t);
    *t = NULL;
}

int altura(NO* A){
    if ( A == NULL ) return -1;
    return A->altura;
}

int atualiza_altura(NO* A){
    if ( A == NULL ) return -1;

    int altura_esq = altura(A->esq);
    int altura_dir = altura(A->dir);

    return ( altura_esq > altura_dir ? altura_esq : altura_dir) + 1 ;
}

NO* rotacao_direita(NO* A){
    NO *B = A->esq;
    NO *T = B->dir;

    B->dir = A;
    A->esq = T;
    
    A->altura = atualiza_altura(A);
    B->altura = atualiza_altura(B);

    return B;
}

NO *rotacao_esquerda(NO *A){
    NO *B = A->dir;
    NO *T = B->esq;

    B->esq = A;
    A->dir = T;

    A->altura = atualiza_altura(A);
    B->altura = atualiza_altura(B);

    return B;
}

NO *rotacao_esquerda_direita(NO *A){
    A->esq = rotacao_esquerda(A->esq);
    return rotacao_direita(A);
}

NO *rotacao_direita_esquerda(NO *A){
    A->dir = rotacao_direita(A->dir);
    return rotacao_esquerda(A);
}

NO *inserir_recursivo(NO *atual, int chave,bool *sucesso){
    if ( atual == NULL ){
        NO *novo = (NO*) malloc(sizeof(NO));
        if (novo == NULL) return NULL;
        novo->altura = 0;
        novo->chave = chave;
        novo->dir = NULL;
        novo->esq = NULL;
        *sucesso = true;
        return novo;
    }

    if ( chave < atual->chave ){
        atual->esq = inserir_recursivo(atual->esq,chave,sucesso);
    }else if ( chave > atual->chave ){
        atual->dir = inserir_recursivo(atual->dir,chave,sucesso);
    }

    atual->altura = atualiza_altura(atual);
    int fb = altura(atual->esq) - altura(atual->dir);

    if ( fb > 1 ){
        NO *esq = atual->esq;
        int fb_esq = altura(esq->esq) - altura(esq->dir);
        if ( fb_esq < 0 ){
            atual = rotacao_esquerda_direita(atual);
        }else{
            atual = rotacao_direita(atual);
        }
    }else if ( fb < -1 ){
        NO *dir = atual->dir;
        int fb_dir = altura(dir->esq) - altura(dir->dir);
        if ( fb_dir > 0 ){
            atual = rotacao_direita_esquerda(atual);
        }else{
            atual = rotacao_esquerda(atual);
        }
    }

    return atual;
}

bool avl_inserir(AVL *t, int chave){
    if ( t == NULL ) return false;
    bool sucesso = false;
    t->raiz = inserir_recursivo(t->raiz,chave,&sucesso);
    return sucesso;
}

void imprimir_recursivo(NO *atual){
    if ( atual == NULL ) return;

    imprimir_recursivo(atual->esq);
    printf("%d ",atual->chave);
    imprimir_recursivo(atual->dir);
}

void avl_imprimir(const AVL *t){
    if ( t == NULL ) return;
    imprimir_recursivo(t->raiz);
}

bool buscar_recursivo(NO *atual, int chave){
    if ( atual == NULL ) return false;

    if ( atual->chave == chave ) return 1;

    if ( chave < atual->chave ) return buscar_recursivo(atual->esq,chave);

    return buscar_recursivo(atual->dir,chave);
}

bool avl_buscar(const AVL *t, int chave){
    if ( t == NULL ) return false;
    return buscar_recursivo(t->raiz,chave);
}

NO *busca_maior_esq(NO *atual){
    if ( atual == NULL ) return NULL;
    while(atual->dir != NULL){
        atual = atual->dir;
    }
    return atual;
}

NO *remover_recursivo(NO *atual, int chave, bool *sucesso){
    if ( atual == NULL ) return NULL;

    if ( chave < atual->chave ){
        atual->esq = remover_recursivo(atual->esq,chave,sucesso);
    }else if ( chave > atual->chave){
        atual->dir = remover_recursivo(atual->dir,chave,sucesso);
    }else{
        *sucesso = true;

        if ( atual->esq == NULL ){
            NO *tmp = atual->dir;
            free(atual);
            return tmp;
        }

        if ( atual->dir == NULL ){
            NO *tmp = atual->esq;
            free(atual);
            return tmp;
        }

        NO *subst = busca_maior_esq(atual->esq);
        atual->chave = subst->chave;
        atual->esq = remover_recursivo(atual->esq,subst->chave,sucesso);
    }

    atual->altura = atualiza_altura(atual);
    int fb = altura(atual->esq) - altura(atual->dir);

    if ( fb > 1 ){
        NO *esq = atual->esq;
        int fb_esq = altura(esq->esq) - altura(esq->dir);
        if ( fb_esq < 0 ){
            atual = rotacao_esquerda_direita(atual);
        }else{
            atual = rotacao_direita(atual);
        }
    }else if ( fb < -1 ){
        NO *dir = atual->dir;
        int fb_dir = altura(dir->esq) - altura(dir->dir);
        if ( fb_dir > 0 ){
            atual = rotacao_direita_esquerda(atual);
        }else{
            atual = rotacao_esquerda(atual);
        }
    }

    return atual;
}

bool avl_remover(AVL *t, int chave){
    if ( t == NULL ) return false;
    bool sucesso = false;
    t->raiz = remover_recursivo(t->raiz,chave,&sucesso);
    return sucesso;
}

int avl_altura(const AVL *t){
    if ( t == NULL ) return -1;
    return altura(t->raiz);
}