#define _POSIX_C_SOURCE 200809L
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "reader_nasa.h"

bool eh_espaco(char c) {
    return (c == ' ' || c == '\t' || c == '\n' || c == '\r' || c == '\v' || c == '\f');
}

void parse_string(char *str_origem, char *str_destino, int tamanho){
    if(str_destino == NULL || tamanho == 0){
        return;
    }
    
    str_destino[0] = '\0';
    if(str_origem == NULL || str_origem[0] == '\0'){
        return;
    }

    // ignora espacos ou aspas no inicio
    while (*str_origem != '\0' && (eh_espaco(*str_origem) || *str_origem == '"')) {
        str_origem++;
    }

    int i = 0;
    while(*str_origem != '\0' && i < tamanho - 1){
        if(*str_origem == '"' || *str_origem == '\r' || *str_origem == '\n'){
            break;
        }
        str_destino[i] = *str_origem;
        i++;
        str_origem++;
    }
    str_destino[i] = '\0';

    while(i > 0 && eh_espaco(str_destino[i-1])){
        str_destino[i-1] = '\0';
        i--;
    }
}

int parse_int(char *str_origem){
    if (str_origem == NULL || str_origem[0] == '\0')
        return 0;

    return atoi(str_origem);
}

long parse_long(char *str_origem){
    if(str_origem == NULL || str_origem[0] == '\0'){
        return 0;
    }
    return atol(str_origem);
}

double parse_double(char *str_origem){
    if(str_origem == NULL || str_origem[0] == '\0'){
        return 0;
    }
    return atof(str_origem);
}

bool parse_bool(char *str_origem){
    if(str_origem == NULL || str_origem[0] == '\0'){
        return 0;
    }

    if(strcmp(str_origem, "True") == 0){
        return 1;
    }
    return 0;
}

char* extrair_campo_csv(char **linha_ptr){
    if(linha_ptr == NULL || *linha_ptr == NULL || **linha_ptr == '\0')
        return NULL;

    char *inicio = *linha_ptr;
    char *p = inicio;
    bool aspas = false;

    while(*p != '\0') {
        if(*p == '"') 
            aspas = !aspas;
        else if(*p == ',' && !aspas){
            *p = '\0';
            *linha_ptr = p + 1;
            return inicio;
        }
        p++;
    }

    *linha_ptr = p;
    return inicio;
}

int reader_nasa_indice_coluna(FILE *fp, const char *nome_coluna){
    if (fp == NULL || nome_coluna == NULL) return -1;

    char linha[1024];
    if (fgets(linha, sizeof(linha), fp) == NULL) return -1;
    linha[strcspn(linha,"\r\n")] = '\0';

    int idx = 0;
    char *campo;
    campo = strtok(linha,",");
    
    while(campo != NULL){
        if (strcmp(campo,nome_coluna) == 0){
            return idx;
        }
        campo = strtok(NULL,",");
        idx++;
    }

    return -1;
}


bool reader_nasa_ler_chave(FILE *fp, int idx_coluna,char *chave, int tam_chave, off_t *offset){
    if (fp == NULL || chave == NULL || offset == NULL || idx_coluna < 0) return false;

    while(1){
        off_t pos = ftello(fp);

        char linha[1024];
        if (fgets(linha, sizeof(linha), fp) == NULL) return false;
        char *inicio = linha;

        if ( linha[0] == '\n' || linha[0] == '\r' || linha[0] == '\0'){
            continue;
        }

        char *campo = NULL;

        for (int i = 0; i <= idx_coluna; i++){
            campo = extrair_campo_csv(&inicio);
        }

        parse_string(campo,chave,tam_chave);

        *offset = pos;
        return true;
        
    }

}

