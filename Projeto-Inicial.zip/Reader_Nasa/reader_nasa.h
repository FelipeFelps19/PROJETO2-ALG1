#ifndef READER_NASA_H
#define READER_NASA_H

#include <stdbool.h>    // bool

// Lê a primeira linha (cabeçalho) e devolve a posição da coluna 'nome_coluna'
// (0, 1, 2, ...), ou -1 se ela não existir. Depois da chamada, o arquivo fica
// posicionado na primeira linha de dados.
int reader_nasa_indice_coluna(FILE *fp, const char *nome_coluna);

// Lê o próximo registro, pulando linhas vazias. Copia para 'chave' o valor da
// coluna 'idx_coluna' ("" se o campo estiver vazio ou ausente) e para '*offset'
// o byte onde a linha começa. Devolve false no fim do arquivo ou em erro.
bool reader_nasa_ler_chave(FILE *fp, int idx_coluna, char *chave, int tam_chave, off_t *offset);

#endif