#define _POSIX_C_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <string.h>
#include "item_indice.h"

struct item_indice {
    char *chave; // chave de busca ( EX : 2028 ) , ou seja, ano 2028 de algum campo
    off_t *offsets; // salva os offsets dos itens que correspondem a chave
    int n_offsets; // indica o numero de offsets encontrados
    int capacidade; // indica a capacidade maxima do vetor de offsets
};

ITEM_INDICE *item_indice_criar(const char *chave, off_t offset){
    ITEM_INDICE *it = (ITEM_INDICE*) malloc(sizeof(ITEM_INDICE));
    if ( it == NULL ) return NULL;

    it->chave = strdup(chave);
    it->capacidade = 4;

    it->offsets = (off_t*) malloc(capacidade * sizeof(off_t));
    if ( it->offsets == NULL ) return NULL;
    
    it->n_offsets[0] = offset;
    it->n_offsets = 1;
}