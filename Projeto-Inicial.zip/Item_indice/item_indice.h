#ifndef ITEM_INDICE_H
#define ITEM_INDICE_H

#include <stdbool.h>
#include <sys/types.h>   

typedef struct item_indice ITEM_INDICE;

// Cria um item com uma cópia da 'chave' e o primeiro offset. Devolve NULL se faltar memória.
ITEM_INDICE *item_indice_criar(const char *chave, off_t offset);

// Libera a chave, o vetor de offsets e o próprio item. Deixa *item = NULL.
void item_indice_apagar(ITEM_INDICE **item);

// Acrescenta um offset ao item, aumentando o vetor se necessário. Devolve false se faltar memória.
bool item_indice_adicionar_offset(ITEM_INDICE *item, off_t offset);

// Getters
const char *item_indice_get_chave(const ITEM_INDICE *item);
int item_indice_get_n_offsets(const ITEM_INDICE *item);
off_t item_indice_get_offset(const ITEM_INDICE *item, int i);

#endif