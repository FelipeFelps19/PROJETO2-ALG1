#ifndef ABB_H
#define ABB_H

#include <stdbool.h>

typedef struct abb ABB;

ABB *abb_criar(void);
void abb_apagar(ABB **t);
bool abb_inserir(ABB *t, int chave);
void abb_imprimir(const ABB *t);
bool abb_buscar(const ABB *t, int chave);
bool abb_remover(ABB *t, int chave);
int abb_altura(const ABB *t);
#endif