#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "abb.h"

typedef struct no{
    int chave;
    struct no* dir;
    struct no* esq;
}NO;

struct abb{
    NO* raiz;
};

ABB *abb_criar(void){
    ABB * ab = (ABB*) malloc(sizeof(ABB));
    if ( ab == NULL ) return NULL;
    ab->raiz = NULL;
    return ab;
}

void apagar_recursivo(NO **atual){
    if ( atual == NULL || *atual == NULL) return;

    apagar_recursivo(&(*atual)->dir);
    apagar_recursivo(&(*atual)->esq);

    free(*atual);
    *atual = NULL;
}

void abb_apagar(ABB **t){
    if ( t == NULL || *t == NULL) return;
    apagar_recursivo(&(*t)->raiz);
    free(*t);
    *t = NULL;
}

NO* inserir_recursivo(NO* atual, int chave){
    if ( atual == NULL ){
        NO* novo = (NO*) malloc(sizeof(NO));
        if (novo == NULL) return NULL;
        novo->chave = chave;
        novo->dir = NULL;
        novo->esq = NULL;
        return novo;
    } 

    if ( chave < atual->chave ) {
        atual->esq = inserir_recursivo(atual->esq,chave);
    }else if( chave > atual->chave) {
        atual->dir = inserir_recursivo(atual->dir,chave);
    }

    return atual;
}

bool abb_inserir(ABB *t, int chave){
    if ( t == NULL ) return 0;
    t->raiz = inserir_recursivo(t->raiz,chave);
    return 1;
}

void imprimir_recursivo ( NO* atual){
    if ( atual == NULL ) return;

    imprimir_recursivo(atual->esq);
    printf("%d ",atual->chave);
    imprimir_recursivo(atual->dir);

}

void abb_imprimir(const ABB *t){
    if ( t == NULL ) return;
    imprimir_recursivo(t->raiz);
}

bool buscar_recursivo( NO* atual, int chave ){
    if ( atual == NULL ) return 0;

    if ( atual->chave == chave ) {
        return 1;
    }else if (atual->chave > chave){
        return buscar_recursivo(atual->esq,chave);
    }else{
        return buscar_recursivo(atual->dir,chave);
    }
} 

bool abb_buscar(const ABB *t, int chave){
    if ( t == NULL ) return 0;
    return buscar_recursivo(t->raiz,chave);
}

NO *buscar_maior_esquerda(NO *atual){
    if (atual == NULL) return NULL;
    while(atual != NULL && atual->dir != NULL){
        atual = atual->dir;
    }
    return atual;
}

NO *remover_recursivo(NO* atual, int chave, bool *sucesso){
    if ( atual == NULL ) {
        *sucesso = false;
        return NULL;
    }

    if ( atual->chave > chave){
        atual->esq = remover_recursivo(atual->esq,chave,sucesso);
    }else if (atual->chave < chave){
        atual->dir = remover_recursivo(atual->dir,chave,sucesso);
    }else{
        *sucesso = 1;
        if ( atual->esq == NULL ){
            NO* tmp = atual->dir;
            free(atual);
            return tmp;
        }
        if ( atual->dir == NULL){
            NO* tmp = atual->esq;
            free(atual);
            return tmp;
        }

        NO *subst = buscar_maior_esquerda(atual->esq);
        atual->chave = subst->chave;
        atual->esq = remover_recursivo(atual->esq,subst->chave,sucesso);
    }
    return atual;
}

bool abb_remover(ABB *t, int chave){
    if ( t == NULL ) return 0;
    bool sucesso = 0;
    t->raiz = remover_recursivo(t->raiz,chave,&sucesso);
    return sucesso;
}

int verifica_altura_recursivo(NO *atual){
    if ( atual == NULL ) return -1;

    int altura_dir = verifica_altura_recursivo(atual->dir);
    int altura_esq = verifica_altura_recursivo(atual->esq);

    if ( altura_dir > altura_esq){
        return altura_dir + 1;
    }else{
        return altura_esq + 1;
    }
}

int abb_altura(const ABB *t){
    if ( t == NULL ) return -1;
    return verifica_altura_recursivo(t->raiz);
}


