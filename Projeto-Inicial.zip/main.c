#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include <strings.h>

// So uns teste q eu tava fazendo p entender o ftello e relembrar o fseeko
int main(){
    FILE *fp = fopen("asteroid_dataset.csv","r");
    char linha[1024];
    while(1){
        off_t pos = ftello(fp);
        if (fgets(linha,sizeof(linha),fp) == NULL ) break;
        printf("%lld: %s",pos,linha);
    }

    fseeko(fp, 16639983, SEEK_SET);
    fgets(linha, sizeof(linha), fp);
    printf("Pulei para la e li: %s", linha);
}